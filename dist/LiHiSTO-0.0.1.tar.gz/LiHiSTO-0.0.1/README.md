# LiHiSTO: List of Hindi STOpwords

A package with a comprehensive list of 820 Hindi Stopwords. You can use
[Github-flavored Markdown](https://guides.github.com/features/mastering-markdown/)
to write your content.